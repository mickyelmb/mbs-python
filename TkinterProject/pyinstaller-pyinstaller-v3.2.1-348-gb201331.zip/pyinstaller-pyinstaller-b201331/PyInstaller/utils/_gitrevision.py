#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "b20133197"     # abbreviated commit hash
commit = "b20133197677b963a6a15eccd691318a5e4245b0"  # commit hash
date = "2017-08-02 15:46:52 -1000"   # commit date
author = "David Vierra <codewarrior@hawaii.rr.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Issue #2623: Fix several Py3.x and unicode issues in versioninfo.py

On Py3, the `/` operator returns a float. All uses of the `/` operator
were used to align an offset to 4-byte (DWORD) boundaries, so these
uses are refactored into `nextDWord()`

On Py3, the `__unicode__` special method no longer exists. It is now
aliased to `__str__` on Py3.

On Py3, `unicode()` no longer exists. All calls to `unicode()` are
replaced by string formatting operations similar to `u"%s" % (foo,)`.
"""
